# Architecture

## Objective

Run a standard XDP loader service on the host network interface and keep the service layout for applications using ports **25566-25665** documented and repeatable.

## Suggested layout

- `25566`: Java primary
- `25567`: Bedrock primary
- `25568`: API / query / status
- `25569-25665`: client or service allocations

## Operational guidance

- Do not collapse Java and Bedrock onto one ambiguous shared port.
- Keep status/query isolated where possible.
- Validate both TCP and UDP paths.
- Treat the XDP loader as one layer in the chain, not the entire traffic policy.

## Data path to validate

1. Upstream anti-DDoS / transit
2. NIC / server interface
3. XDP attach state
4. Host firewall
5. NAT / proxy forwarding
6. Backend listener
7. Application-level query / status response
