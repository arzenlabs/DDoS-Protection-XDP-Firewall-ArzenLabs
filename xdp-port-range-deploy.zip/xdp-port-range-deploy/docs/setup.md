# Setup Guide

## Ubuntu / Debian

### Install basic packages

```bash
sudo apt update
sudo apt install -y curl iproute2 ethtool tcpdump
```

### Clone repo

```bash
git clone https://github.com/YOUR_USERNAME/xdp-port-range-deploy.git
cd xdp-port-range-deploy
```

### Configure

```bash
cp config.env.example config.env
nano config.env
```

### Install service

```bash
chmod +x scripts/*.sh
sudo ./scripts/install.sh
```

### Enable and start

```bash
sudo systemctl enable xdp-loader
sudo systemctl start xdp-loader
```

### Logs

```bash
sudo journalctl -u xdp-loader -f
```

### Stop

```bash
sudo systemctl stop xdp-loader
```
