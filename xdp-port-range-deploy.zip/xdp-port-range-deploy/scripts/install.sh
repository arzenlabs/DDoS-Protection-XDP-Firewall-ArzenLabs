#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

if [ ! -f "$REPO_DIR/config.env" ]; then
  echo "[-] Missing config.env. Copy config.env.example to config.env first."
  exit 1
fi

# shellcheck disable=SC1091
source "$REPO_DIR/config.env"

mkdir -p "$INSTALL_DIR/bin" "$INSTALL_DIR/scripts" "$INSTALL_DIR/systemd" "$INSTALL_DIR/docs"
install -m 0755 "$REPO_DIR/bin/xdp-loader" "$INSTALL_DIR/bin/xdp-loader"
install -m 0755 "$REPO_DIR/scripts/start.sh" "$INSTALL_DIR/scripts/start.sh"
install -m 0755 "$REPO_DIR/scripts/stop.sh" "$INSTALL_DIR/scripts/stop.sh"
install -m 0755 "$REPO_DIR/scripts/verify.sh" "$INSTALL_DIR/scripts/verify.sh"
install -m 0644 "$REPO_DIR/config.env" "$INSTALL_DIR/config.env"
install -m 0644 "$REPO_DIR/docs/architecture.md" "$INSTALL_DIR/docs/architecture.md"
install -m 0644 "$REPO_DIR/docs/setup.md" "$INSTALL_DIR/docs/setup.md"

sed "s|__INSTALL_DIR__|$INSTALL_DIR|g" "$REPO_DIR/systemd/xdp-loader.service" > /etc/systemd/system/xdp-loader.service

systemctl daemon-reload

echo "[+] Installed to $INSTALL_DIR"
echo "[+] Service file: /etc/systemd/system/xdp-loader.service"
echo "[i] Start with: systemctl start xdp-loader"
echo "[i] Enable with: systemctl enable xdp-loader"
