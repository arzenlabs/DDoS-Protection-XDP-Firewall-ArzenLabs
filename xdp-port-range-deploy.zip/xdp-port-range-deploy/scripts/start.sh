#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

# shellcheck disable=SC1091
source "$INSTALL_DIR/config.env"

if [ -z "${INTERFACE:-}" ]; then
  echo "[-] INTERFACE is not set"
  exit 1
fi

CMD=("$INSTALL_DIR/bin/xdp-loader")

if [ -n "${METRICS_ADDR:-}" ]; then
  CMD+=(--metrics-addr "$METRICS_ADDR")
fi

CMD+=("$INTERFACE")

echo "[+] Starting xdp-loader"
echo "[+] Interface: $INTERFACE"
echo "[+] Port range reference: $PORT_START-$PORT_END"
if [ -n "${METRICS_ADDR:-}" ]; then
  echo "[+] Metrics: $METRICS_ADDR"
fi

exec "${CMD[@]}"
