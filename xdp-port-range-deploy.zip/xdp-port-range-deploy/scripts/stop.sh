#!/bin/bash
set -euo pipefail

if systemctl is-active --quiet xdp-loader; then
  systemctl stop xdp-loader
else
  pkill -f '/bin/xdp-loader' || true
fi
