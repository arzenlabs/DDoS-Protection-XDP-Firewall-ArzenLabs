#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

# shellcheck disable=SC1091
source "$INSTALL_DIR/config.env"

echo "== Service status =="
systemctl --no-pager --full status xdp-loader || true

echo
echo "== Interface =="
ip addr show "$INTERFACE" || true

echo
echo "== Port listeners in target range =="
ss -tulnp | awk 'NR==1 || /25566|25567|25568|25569|256[0-5][0-9]|2566[0-5]/'

echo
echo "== Metrics listener =="
if [ -n "${METRICS_ADDR:-}" ]; then
  PORT="${METRICS_ADDR##*:}"
  ss -ltnp | grep ":$PORT" || true
fi
